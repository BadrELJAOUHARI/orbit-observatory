"""Per-lens event-group validation; skip only the lenses that fail data gates."""
import argparse,json,platform
from collections import Counter,defaultdict
from pathlib import Path
from .validation import ROOT,digest,load_config
from .experimental_dataset import OUTPUT,POLICY
from .reviewed import write_immutable
from .training import train_baseline


def validate_prediction(pred):
    from jsonschema import Draft202012Validator
    schema=json.loads((ROOT/'schemas/experimental-v1/prediction.schema.json').read_text())
    Draft202012Validator(schema).validate(pred)
    import math
    if not all(math.isfinite(value) for value in pred['probabilities'].values()) or abs(sum(pred['probabilities'].values())-1)>1e-8 or pred['predicted_label'] not in pred['probabilities']:
        raise ValueError('Invalid experimental class probabilities')


def plan_lens(rows):
    classes=sorted({r['label'] for r in rows});groups=sorted({r['leakage_group_id'] for r in rows})
    class_groups={label:sorted({r['leakage_group_id'] for r in rows if r['label']==label}) for label in classes}
    reasons=[]
    if len(groups)<2:reasons.append(f'Need at least two disjoint event groups; found {len(groups)}')
    if len(classes)<2:reasons.append(f'Need at least two represented supervised classes; found {classes}')
    for label,ids in class_groups.items():
        if len(ids)<2:reasons.append(f'{label} occurs in only {len(ids)} event group; leaving it out removes that class from training')
    folds=[]
    for group in groups:
        train=[r for r in rows if r['leakage_group_id']!=group];val=[r for r in rows if r['leakage_group_id']==group]
        fold=dict(validation_group=group,train_candidate_ids=[r['candidate_id'] for r in train],validation_candidate_ids=[r['candidate_id'] for r in val],
            train_events=sorted({r['event_id'] for r in train}),validation_events=sorted({r['event_id'] for r in val}),train_class_counts=dict(Counter(r['label'] for r in train)),validation_class_counts=dict(Counter(r['label'] for r in val)))
        if len({r['label'] for r in train})<2:fold['blocked']='Training fold has fewer than two classes'
        folds.append(fold)
    return dict(rows=len(rows),events=len({r['event_id'] for r in rows}),groups=len(groups),represented_classes=classes,
        missing_classes=sorted(set(['support','oppose','no_stance','mixed'])-set(classes)),class_counts=dict(Counter(r['label'] for r in rows)),
        class_event_groups={label:len(ids) for label,ids in class_groups.items()},eligible_to_run=not reasons,reasons=reasons,folds=folds)


def load_frozen():
    manifest=json.loads((OUTPUT/'dataset_manifest.json').read_text())
    for name,sha in manifest['files'].items():
        if digest((OUTPUT/name).read_bytes())!=sha:raise ValueError('Frozen dataset artifact changed: '+name)
    if digest(POLICY.read_bytes())!=manifest['policy_sha256']:raise ValueError('Training policy changed after freezing')
    rows=json.loads((OUTPUT/'dataset.json').read_text())
    from .experimental_dataset import validate_training_view
    for row in rows:validate_training_view(row)
    return rows,json.loads((OUTPUT/'training_split.json').read_text()),manifest


def run(destination=None):
    rows,split,manifest=load_frozen();destination=destination or OUTPUT/'experiment'
    snapshot=digest((OUTPUT/'dataset_manifest.json').read_bytes())
    report_path=destination/'experiment_report.json'
    if report_path.exists():
        report=json.loads(report_path.read_text())
        if report['dataset_manifest_sha256']!=snapshot:raise ValueError('Cannot replace prior experiment with different data')
        for name,sha in report['saved_artifacts'].items():
            if digest((destination/name).read_bytes())!=sha:raise ValueError('Experiment artifact hash mismatch')
        return report
    plans={lens:plan_lens([r for r in rows if r['lens_id']==lens]) for lens in load_config()[1]}
    predictions=[];artifacts={};trained=[]
    for lens,plan in plans.items():
        if not plan['eligible_to_run']:
            plan.update(status='skipped_insufficient_data',validation_metrics=None,model_path=None);continue
        import joblib
        from sklearn.metrics import accuracy_score,f1_score,confusion_matrix
        selected=[r for r in rows if r['lens_id']==lens];truth=[];labels=[];weights=[];event_outcomes=defaultdict(list)
        for number,fold in enumerate(plan['folds']):
            group=fold['validation_group'];train=[r for r in selected if r['leakage_group_id']!=group];val=[r for r in selected if r['leakage_group_id']==group]
            prepared=dict(train=train,validation=val,heldout_event_ids=split['excluded_from_training_and_tuning_event_ids'],heldout_leakage_group_ids=split['reserved_leakage_group_ids'])
            model=train_baseline(prepared)
            lensdir=destination/lens;lensdir.mkdir(parents=True,exist_ok=True)
            path=lensdir/f'fold-{number}.joblib';joblib.dump(model,path);artifacts[str(path.relative_to(destination))]=digest(path.read_bytes())
            inputs=[r['proposition']+' [SEP] '+r['passage'] for r in val];out=model.predict(inputs);probs=model.predict_proba(inputs)
            populations=Counter(r['event_id'] for r in val)
            for row,label,prob in zip(val,out,probs):
                truth.append(row['label']);labels.append(str(label));weights.append(1/populations[row['event_id']]);event_outcomes[row['event_id']].append(str(label)==row['label'])
                predictions.append(dict(record_type='experimental_prediction',schema_version='1.0.0',origin='trained_baseline_experiment',candidate_id=row['candidate_id'],
                    event_id=row['event_id'],actor_id=row['actor_id'],actor_role=row['actor_role'],lens_id=lens,text_sha256=row['text_sha256'],
                    predicted_label=str(label),probabilities={str(k):float(v) for k,v in zip(model.classes_,prob)},
                    model_id=lens+'/fold-'+str(number),dataset_manifest_sha256=snapshot,split_role='development_validation_out_of_group',
                    calibrated=False,validated_for_publication=False,alignment_score=None,review_status='machine_unreviewed'))
        # Save an experimental final fit on all eligible development groups after OOF validation.
        # Reuse the exact validated baseline estimator construction for a final fit.
        from .training import baseline_pipeline
        final=baseline_pipeline();final.fit([r['proposition']+' [SEP] '+r['passage'] for r in selected],[r['label'] for r in selected])
        path=destination/lens/'final.joblib';joblib.dump(final,path);artifacts[str(path.relative_to(destination))]=digest(path.read_bytes())
        order=plan['represented_classes']
        plan.update(status='trained_experimental',model_path=str(path.relative_to(destination)),validation_metrics=dict(
            claim_accuracy=accuracy_score(truth,labels),macro_f1_represented_classes=f1_score(truth,labels,labels=order,average='macro',zero_division=0),
            event_weighted_accuracy=accuracy_score(truth,labels,sample_weight=weights),
            event_weighted_confusion_matrix=confusion_matrix(truth,labels,labels=order,sample_weight=weights).tolist(),class_order=order,
            per_event_accuracy={e:sum(values)/len(values) for e,values in event_outcomes.items()}))
        trained.append(lens)
    for pred in predictions:validate_prediction(pred)
    write_immutable(destination/'experimental_predictions.json',predictions)
    artifacts['experimental_predictions.json']=digest((destination/'experimental_predictions.json').read_bytes())
    import sklearn,numpy
    report=dict(version='experimental-baseline-1.0.0',dataset_manifest_sha256=snapshot,dataset_sha256=manifest['files']['dataset.json'],policy_version='experimental-training-2.0.0',
        actual_eligible_rows=len(rows),actual_eligible_events=len({r['event_id'] for r in rows}),actual_eligible_groups=len({r['leakage_group_id'] for r in rows}),
        class_counts=dict(Counter(r['label'] for r in rows)),trained_lenses=trained,real_data_training_executed=bool(trained),lenses=plans,
        validation='Leave one connected communication-event group out; fixed preprocessing and hyperparameters; reserved evaluation never fitted, predicted or tuned.',
        reserved_evaluation_used=False,calibrated=False,public_scores_changed=False,alignment_scores_produced=False,
        annotation_origin='ai_assisted_reviewed',human_independent_check=True,blind_independent_annotation=False,
        runtime=dict(python=platform.python_version(),sklearn=sklearn.__version__,numpy=numpy.__version__),saved_artifacts=artifacts,
        limitations=['Small purposive development sample; no representative country-period estimate.',
            'Human-checked assisted annotations are not blind independent evaluation gold.',
            'Unresolved, source/text/attribution/scope-held items excluded; missing classes not fabricated.',
            'No validation score or model is produced for skipped lenses. No pooled rescue across different targets.'])
    write_immutable(report_path,report);return report


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path);args=parser.parse_args()
    report=run(args.output)
    print(json.dumps(dict(eligible_rows=report['actual_eligible_rows'],eligible_events=report['actual_eligible_events'],trained_lenses=report['trained_lenses'],
        lenses={lens:dict(rows=p['rows'],status=p['status'],reasons=p['reasons']) for lens,p in report['lenses'].items()}),indent=2))

if __name__=='__main__':main()
