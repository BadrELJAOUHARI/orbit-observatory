ORBIT human-verified assisted review and baseline assessment, 23 October 2026

The completed review was imported. No new annotation batch is requested.
45 new human-checked assisted judgments have experimental training approval.
The previous 68 reviews are preserved and were not automatically reapproved.
10 examples across three events pass the source/text/scope gates.
All five lenses fail event/class validation prerequisites: no real-data model,
checkpoint, experimental prediction or validation metric was produced.
See reports/EXPERIMENTAL_BASELINE.md and frozen/experiment/experiment_report.json.
Frozen preprocessing, hashes, inclusion/exclusion ledgers and policy are included.
A separate local evidence API is prepared; public scores and website are unchanged.
The private archive contains development evidence only. Reserved evaluation passages
and full raw source downloads are not included. Keep this private research material.
