ORBIT focal supplement — 25 October 2026

This SUPPLEMENT leaves the old 561-item packet and 113 completed reviews unchanged.
Strict: 48 tasks. Experimental components: 171 tasks.
Genuinely new evidence: 85 pairs. Previously held recovered/reclassified: 134.

1. Extract this ZIP to a permanent folder.
2. Open index.html; strict and components are DIFFERENT review targets.
3. Enter your annotator ID once. Label with context and add brief reasoning.
4. Save progress backups before moving files or switching browser.
5. Export and return the COMPLETE CSV from each review you complete. Filters do not remove exported rows.

Component directions do not replace the strict proposition or W1. Current component fields are experimental AI-generated, unreviewed suggestions. Source/translation/scope holds and earlier judgments remain preserved. No new Badr_A checks, blind independence or training authorization is asserted.

If your browser restricts local HTML, open a terminal in this extracted folder:
  python -m http.server 8765 --bind 127.0.0.1
Then open http://127.0.0.1:8765/index.html and keep that location/port for autosave.
The managed cloud browser blocks file://; the loopback route passed restart/export/import checks. No policy was bypassed.

The held queue and diagnostics are separate reports, not extra main review tasks. Reserved evaluation passages/context are absent. Keep the packet and excerpts private.
