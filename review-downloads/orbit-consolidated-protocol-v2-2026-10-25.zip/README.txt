ORBIT consolidated review, adopted components-v2.0.0

Extract and open review.html. If your browser restricts local HTML, run:
python -m http.server 8765 --bind 127.0.0.1
then open http://127.0.0.1:8765/review.html

780 tasks: 609 strict/full targets and 171 component bundles, over 694 exact passages. Territorial integrity and annexation recognition have separate controls. Scope, conditions, expression and source/attribution/text/language quality are separate. Old strict labels/W1 and all old files remain unchanged.

Import earlier CSV/JSON progress backups through this ONE entry point. Strict responses resume as strict. Old generic component responses remain prior history, not migrated component labels. Conflicts require explicit replacement. Same-origin old browser keys may auto-resume; other browsers/locations require a portable backup. Server cannot inspect drafts on your computer. Enter annotator ID once for edited tasks. Export the complete CSV and a JSON backup before moving files. Export includes every task regardless of filters.

No new suggestions or labels are approved for training. Component eligibility after review/explicit target-scoped approval does not depend on missing unrelated full-target components. Source holds remain binding. No models trained/public scores changed. Reserved evaluation material is excluded.
