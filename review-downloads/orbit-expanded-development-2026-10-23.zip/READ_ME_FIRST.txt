ORBIT consolidated development review, 23 October 2026

1. Extract the ZIP. Open ORBIT_Development_Review_Expanded.html in your browser.
2. Your 68 checked decisions are already imported as previous judgments. Do not re-enter them.
3. Default filters show 12 new mechanically clean tasks. Source/translation/scope review remains necessary; clean is not training approval.
4. Enter Badr_A and review the exact proposition, passage and context. Leave uncertain decisions pending and describe the reason. Keep assistance/non-independence accurate.
5. Work saves in the same browser/file location. Export a progress backup before changing browser or moving the file.
6. Use Export review CSV and return the entire 113-row CSV. Never edit IDs, evidence or history. All prior judgments and holds remain in the repository.
7. Quarantined items are available through the quality filter. No evaluation-event passages or context are in the HTML/CSV. No new AI stance suggestions were generated.

reports/ contains coverage, readiness, the updated plan and territorial proposal. The proposal is not approved and changes no codebook or score. Real-data training remains blocked by the existing approval gates.
