ORBIT first real experimental baselines, 24 October 2026

Two lens models really trained: sanctions and invasion responsibility.
Neither beats its training-fold majority comparator, and both miss all held-out
support examples. These are exploratory support-versus-no_stance experiments,
not opposition detection, political alignment or publication validation.

Eligibility: 10 -> 29 after extended authorization -> 38 after nine documented
source clearances, across eight events. All 113 previous reviews are preserved.
No independent/blind checks were newly asserted. Public scores/design are unchanged.

reports/FIRST_REAL_BASELINES.md contains metrics, per-fold results, clearances,
remaining holds, output paths, commands and limitations.
frozen/ contains the dataset, 113-record grant/ledger, preprocessing, saved final
and fold pipelines, out-of-group predictions and their hashes.
proof/ includes documentary excerpts/metadata and page comparisons. Original full
speech PDFs remain in the private workspace cache; official URLs/hashes are recorded.
changed-code/ contains the changed modules and dependency requirements, to use with
the existing research project. This is not a replacement website.

Only one genuinely new decision is included: C24-M1, an adopted Council military-
assistance paragraph. The AI support suggestion is unreviewed, outside the 113-record
authorization and current models. Read new-decision/ONE_NEW_DECISION.md. No general
labeling batch was created. A label and separate experimental-use approval would be
needed before using that candidate.

The final sklearn pipelines are frozen/experiment/sanctions/final.joblib and
frozen/experiment/invasion_responsibility/final.joblib. Inputs are proposition +
' [SEP] ' + exact stored passage; probabilities are uncalibrated and do not yield
public alignment scores. Runtime versions are recorded in the experiment report.
